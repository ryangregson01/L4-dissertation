from django.contrib import admin
from dashboard.models import Protein

admin.site.register(Protein)
